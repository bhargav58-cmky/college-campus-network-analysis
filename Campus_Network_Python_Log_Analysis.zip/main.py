from pathlib import Path

import matplotlib.pyplot as plt

from network_analyzer import analyze_network_logs
from report_generator import generate_report


BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "network_logs.csv"
REPORT_DIR = BASE_DIR / "reports"


def show_graphs(results):
    """Display a status chart and, when available, response-time chart."""
    labels = ["Successful", "Failed"]
    values = [results["successful_tests"], results["failed_tests"]]

    plt.figure(figsize=(8, 5))
    plt.bar(labels, values)
    plt.title("Campus Network Connectivity Results")
    plt.xlabel("Test Status")
    plt.ylabel("Number of Tests")
    plt.tight_layout()
    plt.show()

    average = results["average_response_time"]
    if average is not None:
        plt.figure(figsize=(7, 5))
        plt.bar(["Average Response Time"], [average])
        plt.title("Average Successful Ping Response Time")
        plt.ylabel("Response Time (ms)")
        plt.tight_layout()
        plt.show()


def main():
    print("College Campus Network Design")
    print("Cisco Packet Tracer Simulation with Python-Based Network Log Analysis")

    results = analyze_network_logs(LOG_FILE)
    if results is None:
        print("Analysis could not be completed. Check network_logs.csv.")
        return

    generate_report(results, REPORT_DIR)
    show_graphs(results)


if __name__ == "__main__":
    main()
