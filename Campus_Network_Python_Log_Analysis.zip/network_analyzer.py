import pandas as pd


REQUIRED_COLUMNS = {
    "timestamp", "source_ip", "destination_ip",
    "protocol", "status", "response_time_ms"
}


def analyze_network_logs(file_path="network_logs.csv"):
    """Read and summarize network connectivity records."""
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"Error: '{file_path}' was not found.")
        return None
    except pd.errors.EmptyDataError:
        print("Error: The CSV file is empty.")
        return None
    except pd.errors.ParserError as exc:
        print(f"Error: Could not parse the CSV file: {exc}")
        return None

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        print("Error: Missing CSV columns:", ", ".join(sorted(missing)))
        return None
    if df.empty:
        print("No network log records are available.")
        return None

    df["status"] = df["status"].astype(str).str.strip().str.upper()
    df["response_time_ms"] = pd.to_numeric(
        df["response_time_ms"], errors="coerce"
    )
    df = df[df["status"].isin(["SUCCESS", "FAILED"])].copy()

    if df.empty:
        print("No valid SUCCESS or FAILED records were found.")
        return None

    total = len(df)
    successful = int((df["status"] == "SUCCESS").sum())
    failed_count = int((df["status"] == "FAILED").sum())
    success_rate = successful / total * 100
    failure_rate = failed_count / total * 100

    successful_times = df.loc[
        df["status"] == "SUCCESS", "response_time_ms"
    ].dropna()

    average = float(successful_times.mean()) if not successful_times.empty else None
    minimum = float(successful_times.min()) if not successful_times.empty else None
    maximum = float(successful_times.max()) if not successful_times.empty else None

    failed = df[df["status"] == "FAILED"].copy()
    failure_summary = (
        failed.groupby(["source_ip", "destination_ip"])
        .size()
        .reset_index(name="failure_count")
        .sort_values("failure_count", ascending=False)
    )

    print("\n" + "=" * 55)
    print("       COLLEGE CAMPUS NETWORK ANALYSIS")
    print("=" * 55)
    print(f"Total connectivity tests : {total}")
    print(f"Successful tests         : {successful}")
    print(f"Failed tests             : {failed_count}")
    print(f"Success rate             : {success_rate:.2f}%")
    print(f"Failure rate             : {failure_rate:.2f}%")

    if average is None:
        print("Average response time    : Not available")
    else:
        print(f"Average response time    : {average:.2f} ms")
        print(f"Minimum response time    : {minimum:.2f} ms")
        print(f"Maximum response time    : {maximum:.2f} ms")

    print("\nFAILED CONNECTIONS")
    print("-" * 55)
    if failed.empty:
        print("No failed connections detected.")
    else:
        for _, row in failed.iterrows():
            print(f"{row['source_ip']} -> {row['destination_ip']}")

    print("\nREPEATED FAILURE SUMMARY")
    print("-" * 55)
    if failure_summary.empty:
        print("No failed connections detected.")
    else:
        for _, row in failure_summary.iterrows():
            print(
                f"{row['source_ip']} -> {row['destination_ip']}: "
                f"{row['failure_count']} failure(s)"
            )
    print("=" * 55)

    return {
        "data": df,
        "total_tests": total,
        "successful_tests": successful,
        "failed_tests": failed_count,
        "success_rate": success_rate,
        "failure_rate": failure_rate,
        "average_response_time": average,
        "maximum_response_time": maximum,
        "minimum_response_time": minimum,
        "failed_connections": failed,
        "failure_summary": failure_summary,
    }
