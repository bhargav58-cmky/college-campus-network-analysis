PYTHON NETWORK LOG ANALYSIS

Open this folder in VS Code. Install dependencies with `python -m pip install -r requirements.txt`, then run `python main.py`.

Edit network_logs.csv using its existing header. Use SUCCESS or FAILED for status and response time in milliseconds. The included records are examples only and are not automatically collected from Packet Tracer. Replace them with results from your own ping tests. Reports are written to reports/.
