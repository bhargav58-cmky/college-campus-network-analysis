import os
from datetime import datetime


def generate_report(results, output_folder="reports"):
    """Write a text summary and CSV of failed connectivity tests."""
    if results is None:
        print("No analysis results available.")
        return

    os.makedirs(output_folder, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    text_path = os.path.join(output_folder, f"network_report_{stamp}.txt")
    csv_path = os.path.join(output_folder, f"failed_connections_{stamp}.csv")

    results["failed_connections"].to_csv(csv_path, index=False)

    lines = [
        "COLLEGE CAMPUS NETWORK DESIGN",
        "PYTHON-BASED NETWORK LOG ANALYSIS",
        "=" * 45,
        f"Report generated: {datetime.now():%Y-%m-%d %H:%M:%S}",
        "",
        f"Total tests: {results['total_tests']}",
        f"Successful tests: {results['successful_tests']}",
        f"Failed tests: {results['failed_tests']}",
        f"Success rate: {results['success_rate']:.2f}%",
        f"Failure rate: {results['failure_rate']:.2f}%",
    ]

    average = results["average_response_time"]
    lines.append(
        f"Average successful response time: {average:.2f} ms"
        if average is not None else
        "Average successful response time: Not available"
    )
    lines.extend(["", "FAILED CONNECTIONS", "-" * 45])

    failed = results["failed_connections"]
    if failed.empty:
        lines.append("No failed connections detected.")
    else:
        for _, row in failed.iterrows():
            lines.append(f"{row['source_ip']} -> {row['destination_ip']}")

    lines.extend([
        "",
        "Note: Failed tests require investigation and do not alone identify",
        "the cause of a network problem."
    ])

    with open(text_path, "w", encoding="utf-8") as file:
        file.write("\n".join(lines))

    print("\nReports generated successfully!")
    print(f"Text report: {text_path}")
    print(f"Failed connections CSV: {csv_path}")
